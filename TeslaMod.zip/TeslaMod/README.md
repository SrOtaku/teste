# TeslaMod
 É um mod simples. Estou ultilizando mais para conhecer a programação java, então decidi brincar um pouco com o mod do mindustry. 
     
## Aviso

Aliás pode conter erros de programação, 
pode se sentir a vontade para me corrigir kkk. 
 
## English version

A simple mod for testing. I am beginner so it will contain several errors in mod programming.                    :') 

## Segundo Aviso

  Provavelmente eu vou atualizar o mod ou fazer manutenções as vezes então não esperem muita coisa de um iniciante e também caso alguem queria me ajuda me chama ai no discord. 
   
   Meu nick no discord:`~RedGame69~teus#4751`